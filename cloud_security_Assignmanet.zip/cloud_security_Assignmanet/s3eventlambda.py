import json
import boto3
from datetime import datetime

# Initialize the DynamoDB client
dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    # Reference to the DynamoDB table
    table = dynamodb.Table('UploadDetails')  # Make sure to create this table
    
    # Loop through records provided by S3 trigger
    for record in event['Records']:
        s3 = record['s3']
        bucket_name = s3['bucket']['name']
        object_key = s3['object']['key']
        size = s3['object'].get('size', 0)  # Object size in bytes
        
        # Insert details into DynamoDB
        response = table.put_item(
            Item={
                'Timestamp': datetime.now().isoformat(),  # Adjusted attribute name here
                'BucketName': bucket_name,
                'ObjectName': object_key,
                'SizeBytes': size
            }
        )
    
    return {
        'statusCode': 200,
        'body': json.dumps('Success!')
    }
