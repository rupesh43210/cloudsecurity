import json
import boto3
import os
from datetime import datetime, timedelta

# Initialize the SES and DynamoDB clients
ses = boto3.client('ses')
dynamodb = boto3.resource('dynamodb')

def determine_object_type(object_key):
    # Extract file extension and use it to infer file type
    file_extension = os.path.splitext(object_key)[1].lower()
    if file_extension in ['.jpg', '.jpeg', '.png', '.gif']:
        return 'Image'
    elif file_extension in ['.txt', '.log', '.md']:
        return 'Text'
    elif file_extension in ['.pdf']:
        return 'PDF'
    elif file_extension in ['.zip', '.tar', '.gz', '.rar']:
        return 'Archive'
    else:
        return 'Other'

def lambda_handler(event, context):
    # Determine trigger source
    source = context.invoked_function_arn.split(':')[-1] if ':' in context.invoked_function_arn else None

    # Handling different sources
    if source == 'api-gateway':
        body = json.loads(event.get('body', '{}'))
        current_date = body.get('date', datetime.now().strftime('%B %d, %Y'))
    else:
        # Default to current date if triggered by other sources like CloudWatch
        current_date = datetime.now().strftime('%B %d, %Y')

    # Reference to the DynamoDB table
    table = dynamodb.Table('UploadDetails')  # Ensure this table exists
    
    # Calculate start of the day
    start_of_day = datetime.now() - timedelta(hours=datetime.now().hour, minutes=datetime.now().minute, seconds=datetime.now().second, microseconds=datetime.now().microsecond)
    
    # Scan DynamoDB for today's records
    response = table.scan(
        FilterExpression='#ts >= :val',
        ExpressionAttributeNames={'#ts': 'Timestamp'},
        ExpressionAttributeValues={':val': start_of_day.isoformat()}
    )
    
    items = response['Items']
    
    # Format the email content in HTML
    email_content = f"""
<html>
    <head>
        <style>
            body {{
                font-family: 'Arial', sans-serif;
                margin: 0;
                padding: 0;
                background-color: #f4f4f4;
            }}
            .container {{
                max-width: 800px;
                margin: auto;
                background: white;
                padding: 20px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }}
            h2 {{
                color: #333;
                text-align: center;
            }}
            table {{
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }}
            th, td {{
                border: 1px solid #ddd;
                padding: 8px;
                text-align: left;
            }}
            th {{
                background-color: #f8f8f8;
            }}
            tr:nth-child(even) {{
                background-color: #f9f9f9;
            }}
            tr:hover {{
                background-color: #f1f1f1;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <h2>BITS Cloud Security Assignment</h2>
            <h2>Daily Upload Summary for {current_date}</h2>
            <table>
                <tr>
                    <th>Serial No.</th>
                    <th>Date of Upload</th>
                    <th>S3 URI</th>
                    <th>Object Name</th>
                    <th>Object Size (bytes)</th>
                    <th>Object Type</th>
                </tr>
    """

    for index, item in enumerate(items, start=1):
        object_type = determine_object_type(item['ObjectName'])
        upload_date = item.get('Timestamp', 'Unknown Date')
        # Assuming the 'Timestamp' attribute is in ISO format
        readable_upload_date = datetime.fromisoformat(upload_date).strftime('%B %d, %Y %H:%M:%S') if upload_date != 'Unknown Date' else 'Unknown Date'
        email_content += f"""
                <tr>
                    <td>{index}</td>
                    <td>{readable_upload_date}</td>
                    <td>s3://{item['BucketName']}/{item['ObjectName']}</td>
                    <td>{item['ObjectName']}</td>
                    <td>{item['SizeBytes']}</td>
                    <td>{object_type}</td>
                </tr>
        """

    email_content += """
            </table>
        </div>
    </body>
</html>
    """

    # Send the email with HTML formatting
    ses.send_email(
        Source='2022mt13177@wilp.bits-pilani.ac.in',
        Destination={
            'ToAddresses': [
                '2022mt13177@wilp.bits-pilani.ac.in',
                '2022mt13035@wilp.bits-pilani.ac.in',
                '2022mt13163@wilp.bits-pilani.ac.in',
                '2022mt13197@wilp.bits-pilani.ac.in',
                
                # ... add more recipients as needed
            ]
        },
        Message={
            'Subject': {
                'Data': f'S3 Upload Summary for {current_date}'
            },
            'Body': {
                'Html': {
                    'Data': email_content
                },
                'Text': {
                    'Data': "Non-HTML email content"
                }
            }
        }
    )
    
    return {
        'statusCode': 200,
        'body': json.dumps('Email sent successfully!')
    }
