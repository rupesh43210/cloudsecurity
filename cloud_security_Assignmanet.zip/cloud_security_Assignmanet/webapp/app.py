from flask import Flask, request, redirect, url_for, render_template, session
import boto3
import os
from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env file

app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'your_very_secret_key')

# AWS S3 setup
s3 = boto3.client(
    's3',
    aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
    aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
    region_name=os.getenv('AWS_DEFAULT_REGION')
)
BUCKET_NAME = 'uploadsummary'

# Simple user database
users = {}

@app.route('/')
def home():
    if 'username' in session:
        return render_template('upload.html')
    return render_template('login.html')

@app.route('/register', methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users:
            return render_template('register.html', message="User already exists. Please log in or use a different username.")
        users[username] = password
        return render_template('register.html', message="Congratulations! You have been registered successfully.")
    return render_template('register.html')

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users and users[username] == password:
            session['username'] = username
            return redirect(url_for('home'))
        else:
            return render_template('login.html', error="Invalid credentials")
    return render_template('login.html')

@app.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return 'No file part'
    file = request.files['file']
    if file.filename == '':
        return 'No selected file'
    if file:
        file.save(file.filename)
        s3.upload_file(
            Bucket=BUCKET_NAME,
            Filename=file.filename,
            Key=file.filename
        )
        return 'File uploaded successfully'

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('home'))

@app.route('/contents')
def contents():
    if 'username' in session:
        bucket_contents = s3.list_objects(Bucket=BUCKET_NAME)
        files = [file['Key'] for file in bucket_contents.get('Contents', [])]
        return render_template('contents.html', files=files)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
